export { default } from './src/datetime-picker.vue';
