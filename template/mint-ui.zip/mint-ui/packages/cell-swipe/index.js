export { default } from './src/cell-swipe.vue';
