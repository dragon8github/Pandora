export { default } from './src/progress.vue';
