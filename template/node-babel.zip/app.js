import { sayHi, sayBey } from './lib'
import Person from './Person'

sayHi()
sayBey()

const p = new Person('Lee', 18)
console.log(p.toString())