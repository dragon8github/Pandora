export const sayHi = () => {
	console.log('hi...')
}

export const sayBey = () => {
	console.log('Bey...')
}