# aptWaiter

```
npm run dev:weapp
```