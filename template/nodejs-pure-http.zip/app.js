/* 
$ npm install -g nodemon
$ nodemon --inspect app.js
 */
const http = require('http')

http.createServer((req, res) => {

	const { url, method, headers } = req

	let body = ''

	req.on('data', chunk => {
		body += chunk
	})

	// 需要 POSTMAN 发送 POST application/json 请求才可以
	req.on('end', () => {
		res.statusCode = 200
		res.statusMessage = 'success'
		res.setHeader('Content-Type', 'application/json')

		/* 
		res.writeHead(200, 'success', { 
			'Content-Type': 'text/html',
			'Content-Length': body.length
		})
		 */

		res.write(JSON.stringify({
			code: 200,
			msg: 'success',
			data: [
				{ id: 1, title: '中国机长票房破10亿' },
				{ id: 2, title: '我和我的祖国票房新' },
				{ id: 3, title: '惠普计划裁员16' },
				{ id: 4, title: '谢依霖怀二胎新' },
				{ id: 5, title: '中国女排重回第一' },
			]
		}))

		res.end()
	})

	// res.end('Hello World')
	
}).listen(8080, () => console.log('Listening on 8080'))