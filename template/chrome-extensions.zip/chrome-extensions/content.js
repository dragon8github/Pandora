console.log('postDoge...')

var vue = new Vue({
    el: '#app',
    data: {
        items: [1,2,3],
    },
    methods: {
        handleClick () {
        }
    },
    beforeMount: function () {
       
    }
})
