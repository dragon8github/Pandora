document.addEventListener('DOMContentLoaded', function(event) {
   document.getElementById('btn').addEventListener('click', (event) => {
	    console.log(123);
	})
})