/*********************************************************************************/
/**********             鎵€鏈夊皬绀轰緥涓敤鍒扮殑鍏叡JS鍑芥暟          ***********************/
/*********************************************************************************/

// 鍏抽棴娴姩绐楀彛
/**
 function closeDialog(dialog){
	$("#"+dialog).fadeOut(600); 
}
 */
// 鍚戜笂鍚戜笅婊戝姩娴姩绐楀彛
function slideToggleDialog(dialog){
    /**
     $($("#" + dialog + " > div")[1]).slideToggle("slow", function(){
        if ($("#" + dialog + " > div")[1].style.display == "none") {
            $("#" + dialog + " > div").find("img")[0].src = "../../images/openD.png";
        }
        else {
            $("#" + dialog + " > div").find("img")[0].src = "../../images/closeD.png";
        }
    });
     */
    /**
     $(".bgiframe-bottom").slideToggle("slow");
     */
    //鑾峰彇鎸囧畾瀵硅薄
    function getNode(parentDiv,nodeName){
        for(var i = 0,len = parentDiv.childNodes.length; i < len; i++){
            var node = parentDiv.childNodes[i];
            if(nodeName == "content"){
                if(node.className != "dtitle" && node.nodeName == "DIV"){
                    return node;
                }
            }
            else if(nodeName == "img"){
                if(node.className == "dtitle"){
                    var img = node.getElementsByTagName("img")[0];
                    return img;
                }
            }
            else if(nodeName == "iframe"){
                if(node.nodeName == "IFRAME" && node.className == "bgiframe bgiframe-bottom"){
                    return node;
                }
            }
        }
    }
    //鑾峰彇寮瑰嚭div瀵硅薄
    var dialog = document.getElementById(dialog);
    //鑾峰彇鍥剧墖瀵硅薄
    var img = getNode(dialog,"img");
    //鑾峰彇寮瑰嚭绐楀彛涓璪ody鍐呭鐨刣iv瀵硅薄
    var body = getNode(dialog,"content");
    //鑾峰彇涓夌淮涓殑iframe
    var iframe = getNode(dialog,"iframe");
    //澶勭悊
    if(dialog.style.height == "auto"){
        dialog.style.height = "18px";
        img.src = "../../images/openD.png";
        body.style.display = "none";
        if(iframe != null)
            iframe.style.display = "none";
    }else{
        dialog.style.height = "auto";
        img.src = "../../images/closeD.png";
        body.style.display = "block";
        if(iframe != null)
            iframe.style.display = "block";
    }
}

/**
 * 瑕嗙洊setTimeout
 */
/*
var _st = window.setTimeout;

window.setTimeout = function(fRef, mDelay){
    if (typeof fRef == 'function') {
        var argu = Array.prototype.slice.call(arguments, 2);
        var f = (function(){
            fRef.apply(null, argu);
        });
        return _st(f, mDelay);
    }
    return _st(fRef, mDelay);
}

var shimsHandleDivObj = null;
*/
/**
 * 鍒囨崲鎸夐挳div鑾峰彇鐒︾偣
 */
/*
function shimsHandle(divId){
    if(!shimsHandleDivObj) {
        // 娴姩绐楀彛
        shimsHandleDivObj = document.getElementById(divId);
    }
    shimsHandleDivObj.onfocus = "true";
    setTimeout("shimsHandle('"+divId+"')", 300);
}
*/