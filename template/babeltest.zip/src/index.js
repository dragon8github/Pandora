ReactDOM.render(
　　 <h1> Hello, world! < /h1>,
    document.getElementById('app')
);

var nav_li = ['最新电影', '最新评论'];
ReactDOM.render( <
    ul > {
        nav_li.map(function(item) {
            return <li> <a href = '#'> { item } </a></li> ;
        })
    } </ul>,
    document.getElementById('navbar')
)

class Welcome extends React.Component {
    render() {
        return <h1> Hello, { this.props.name } </h1>;
    }
}
ReactDOM.render( 
    <Welcome name = "Sara" /> ,
    document.getElementById('Welcome')
);