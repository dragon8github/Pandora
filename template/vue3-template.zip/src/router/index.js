import Vue from 'vue'
import Router from 'vue-router'
import store from '../store'
Vue.use(Router)

// 工作室
const Studio = r => require.ensure([], () => r(require('@/pages/Studio.vue')), 'Studio')

// 路由配置
var router = new Router({
  // 哈希模式
  mode: 'hash',
  // 路由导航
  routes: [
    // 首页 > 重定向 > 工作室
    { path: '/', redirect: '/Studio' },
    // 工作室
    { path: '/Studio', name: 'Studio', meta: { title: '工作室' }, component: Studio },
    
  ]
})


// 全局路由钩子
router.afterEach((to, from) => {

})

router.beforeEach((to, from, next) => {
    // 放行页面
    next()
})

export default router