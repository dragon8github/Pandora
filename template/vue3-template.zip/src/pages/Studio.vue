<template>
    <div class="Studio">
        Studio
    </div>
</template>

<script>
export default {
  name: 'Studio',
  data () {
    return {
        items: [],
        title: 'HelloWorld'
    }
  },
  methods: {
      go () {
          console.log('go');
      }
  },
  components: {

  },
  computed: {

  },
  watch: {

  },
  beforeMount () {
      console.log(20190420080022, 'Studio');
  }
}
</script>

<style lang="scss" scoped>
@import "~@/scss/functions.scss";
.Studio {

}
</style>