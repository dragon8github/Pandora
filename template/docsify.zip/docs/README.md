# Window 键盘钩子

> 必须打开 run.exe，并且华为的 『DGIOC.url』 和 『Kill_IE.bat』 必须放置再桌面上。

- CTRL + N : 打开南建演示项目，同时执行『Kill_IE.bat』释放华为的项目，释放GPU；
- CTRL + H : 打开华为演示项目，同时KILL Google Chrome，释放GPU；
- ALT + Enter： 切换窗口/最大化

# 12345 键盘钩子

###### 🚀 路由跳转
- SHIFT + 1： 进入 『总体情况』
- SHIFT + 2： 进入 『事项分类』
- SHIFT + 3： 进入 『部门情况』
- SHIFT + 4： 进入 『事发地情况』
- SHIFT + 5： 进入 『专题分类』
	- SHIFT + Q： 进入 『专题分类 - 城市管理』
	- SHIFT + W： 进入 『专题分类 - 行政效能』
	- SHIFT + E： 进入 『专题分类 - 环境保护』
	- SHIFT + R： 进入 『专题分类 - 交通管理』


###### ⏰ 时间选择器
- SHIFT + t： 切换到今天
- SHIFT + ↑： 切换到上半年
- SHIFT + ↓： 切换到下半年
- SHIFT + →： 切换到全年


###### 📝 辅助操作
- SHIFT + R： 刷新页面并且清空缓存
- SHIFT + ALT： 打开地图快捷键

# 部署

1. hz-12345 编译前端工程
> npm run build

2. 压缩为zip

3. 登录 http://19.104.40.21/users/first-login/

4. 打开 『Web 终端』 和 『文件管理』

5. 将 zip 放入 『文件管理』

6. 从『Web 终端』进入 12345 的命令台

7. 执行以下命令

```bash
> cd /tmp

> ./develop.sh
```