import Vue from 'vue'
import Vuex from 'vuex'

// base
import mutations from './base/mutations.js'
import * as actions from './base/actions'
import * as getters from './base/getters'
import * as state from './base/state.js'

// modules
import AppData from './modules/AppData'

Vue.use(Vuex)

const store = new Vuex.Store({
    strict: false,
    state,
    getters,
    actions,
    mutations,
    modules: {
        AppData,
    },
})

export default store