import * as type from './mutation-types.js'

const mutations = {
	[type.SET_TITLE] (state, title) {
		state.title = title
	}
}

export default mutations;