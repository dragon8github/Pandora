import * as type from './mutation-types.js'

export const set_fetch_count = ({commit, state}) => {
	// TODO
}