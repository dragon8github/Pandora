<template>
    <div class="Studio">
        <el-button @click='go' type='primary'>返回</el-button>
    </div>
</template>

<script>
export default {
  name: 'Studio',
  data () {
    return {
        items: [],
        title: 'HelloWorld'
    }
  },
  methods: {
      go () {
          console.log('go');
      }
  },
  components: {

  },
  computed: {

  },
  watch: {

  },
  beforeMount () {
      console.log(20190507230923, 'Studio');
  }
}
</script>

<style lang="scss" scoped>
@import "~@/scss/functions.scss";
.Studio {

}
</style>