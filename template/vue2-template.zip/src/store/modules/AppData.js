import { request } from '@/utils/request.js'
import router from '@/router'

let state = {
    
}

const actions = {
  
}

export default {
  namespaced: true,
  state,
  actions,
}