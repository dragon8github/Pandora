import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import vueWaves from './directive/waves/waves'
import { maybe } from './utils/utils'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

import '@/scss/utils.scss'

Vue.use(ElementUI)
Vue.use(vueWaves)

Vue.mixin({
  methods: {
	maybe,
  }
})

new Vue({
  render: h => h(App),
  router,
  store,
}).$mount('#app')