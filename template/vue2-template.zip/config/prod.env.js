'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '""',
  AUTH_CONFIG: '{\n' +
  '  authority: \'https://hui-m.dgjy.net\',\n' +
  '  client_id: \'636893823868935009\',\n' +
  '  redirect_uri: \'http://datacenter.dgdatav.com:6080\',\n' +
  '  response_type: \'code token id_token\',\n' +
  '  scope: \'openid PermissionApi\',\n' +
  '  post_logout_redirect_uri: \'http://datacenter.dgdatav.com:6080\'\n' +
  '}'
}
