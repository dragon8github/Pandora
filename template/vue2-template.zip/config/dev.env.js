'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  BASE_API: '""',
  AUTH_CONFIG: '{\n' +
  '  authority: \'https://testhui.dgjy.net:5000\',\n' +
  '  client_id: \'636893823868935009\',\n' +
  '  redirect_uri: \'http://localhost:8080\',\n' +
  '  response_type: \'code token id_token\',\n' +
  '  scope: \'openid PermissionApi\',\n' +
  '  post_logout_redirect_uri: \'http://localhost:8080\'\n' +
  '}'
})
