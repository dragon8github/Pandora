<p align="center"><img src="http://wx3.sinaimg.cn/large/006ar8zggy1g18fkeqx4bj305k05kmx2.jpg"></p>

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

# Contributors

李钊鸿 📧 928532756@qq.com 

[http://cylee.top](http://cylee.top)
