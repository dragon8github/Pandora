<template>
  <div id="app">
    <button class="abc"><MdRipple></MdRipple></button>
  </div>
</template>

<script>
import HelloWorld from "./components/HelloWorld";
import MdRipple from "./components/MdRipple.vue";
export default {
  name: "App",
  components: {
    HelloWorld,
    MdRipple
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

.abc {
  width: 100px;
  height: 100px;
  padding: 0;
}
</style>
