<template>
  <transition name="md-ripple" @after-enter="end">
    <span v-if="animating" />
  </transition>
</template>

<script>
export default {
  name: "MdWave",
  data() {
    return {
      animating: true
    };
  },
  props: {
    waveClasses: null,
    waveStyles: null
  },
  methods: {
    end() {
      this.animating = null;
      this.$emit("md-end");
    }
  }
};
</script>

<style lang="scss">
.md-ripple-enter-active {
  transition: 0.8s cubic-bezier(0.25, 0.8, 0.25, 1);
  transition-property: opacity, transform;
  will-change: opacity, transform;

  &.md-centered {
    transition-duration: 1.2s;
  }
}
.md-ripple-enter {
  opacity: 0.26;
  transform: scale(0.26) translateZ(0);
}
</style>
