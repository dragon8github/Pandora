# echarts 东莞地图 + 中国地图 + 广东地图

请使用 chrome 浏览器非安全模式打开

> --args --disable-web-security --user-data-dir