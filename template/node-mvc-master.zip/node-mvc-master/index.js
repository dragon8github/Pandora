const {
  PI,
  substraction,
} = require('./modules');

console.log(PI);
console.log(substraction(10)(5));