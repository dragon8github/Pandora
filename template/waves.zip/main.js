import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'

import vueWaves from './directive/waves'
Vue.use(vueWaves)

new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>',
})


